################################################################################
# mission_seven.py
#
# Description:
# [Describe What your mission does here]
#
# Author(s): [Your Name(s)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.tools import wait, StopWatch

def mission_seven(r):
    print("Running Mission 7")
    # THIS IS CAMS CODE NO TOUCH
    # r.robot.straight(600)
    r.robot.straight(50)
    r.ram.run_time(1000,500)
    r.lam.run_time(400,600)
    r.robot.straight(50)
    r.robot.straight(60)
    r.lam.run_time(-400,600)
    r.robot.straight(-110)

################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()