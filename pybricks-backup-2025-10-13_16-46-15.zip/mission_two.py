################################################################################
# mission_two.py
#
# Description:
# [Describe What your mission does here]
#
# Author(s): [Your Name(s)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.tools import wait, StopWatch

def mission_two(r):
    print("Running Mission 2")
    # Your code goes here...
    r.robot.straight (-425)
    #ITS HAMMER TIME
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.ram.run_time(-400,1000)
    r.robot.turn(-45)
    r.robot.straight(-310)
    r.robot.turn(120)
    r.robot.straight(-75)
    r.robot.turn(-50)
    r.robot.turn(-38)
    wait(1000)
    r.robot.turn(-60)
    r.robot.straight(200)
    #r.robot.turn (10)
    #r.robot.drive(200,-100)
    # r.robot.stop()
################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()