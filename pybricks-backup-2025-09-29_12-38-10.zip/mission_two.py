################################################################################
# mission_two.py
#
# Description:
# [Describe What your mission does here]
#
# Author(s): [Your Name(s)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.tools import wait, StopWatch

def mission_two(r):
    print("Running Mission 2")
    # Your code goes here...
    r.robot.straight (420)
    #ITS HAMMER TIME
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.ram.run_time(400,1000)
    r.ram.run_time(-400,1000)
    r.robot.straight (-500)
################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()