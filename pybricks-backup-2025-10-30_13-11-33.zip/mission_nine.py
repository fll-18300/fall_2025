################################################################################
# mission_nine.py
#
# Description:
# [Describe What your mission does here]
#
# Author(s): [Your Name(s)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.parameters import *
from pybricks.tools import *

def mission_nine(r):
     print("Running Mission 9")
     r.robot.straight(400)
     r.robot.arc(320,90)
     r.robot.straight(150, then=Stop.COAST_SMART)
     r.robot.turn(-90)
     r.robot.straight(-40)
     r.ram.run_time(-400,2000, then=Stop.COAST)
     r.robot.straight(25)
     r.robot.turn(-38)
     r.robot.straight(6)
     r.ram.run_time(400,2000)


################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()