################################################################################
# mission_one.py
#
# Description:
# [Describe What your mission does here]
#
# Author(kyle): [Your Name(kyle)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.tools import wait, StopWatch

def mission_one(r):
    print("Running Mission 1")
    # Kyles code
    # Sample Code: Run attachment motors and drive motors
    r.robot.straight(323)
    r.lam.run_time(500,2529)
    r.robot.straight(-200)
    r.robot.straight(30)
    r.lam.run_time(-650,2529)
    r.robot.straight(-350)
################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()